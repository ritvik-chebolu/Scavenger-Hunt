#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 12:15:51 2022

@author: ashinianantharaman
"""

import matplotlib.pyplot as plt
import numpy as np

def read_waveforms(LA, RV, RA) :
    infile = open('/Users/ashinianantharaman/Desktop/Ashu/WORK/Studies/ISTE 782/Assignment/02/waveforms.csv', 'r')

    line = infile.readline()
    wf = 0 # which waveform are we trying to read (0 = LA, 1 = RV, 2 = RA)

    while line :
        line = line.strip()
        data = line.split(',')

        for i in range(0, len(data)) : 
            data[i] = float(data[i])

        if(wf == 0) :
            LA.append(data)
        elif(wf == 1) :
            RV.append(data)
        elif(wf == 2) :
            RA.append(data)
        
        wf = (wf + 1) % 3
        line = infile.readline()

    infile.close()

def read_times(TL, TR) :
    infile = open('/Users/ashinianantharaman/Desktop/Ashu/WORK/Studies/ISTE 782/Assignment/02/times.csv', 'r')
    line = infile.readline()
    data = line.strip().split(',')

    for i in range(0, len(data)) : 
        data[i] = float(data[i])*1000

    TL.append(data)

    line = infile.readline()
    data = line.strip().split(',')

    for i in range(0, len(data)) : 
        data[i] = float(data[i])*1000

    TR.append(data)
    infile.close()

def plot_waveforms(LA, RV, RA, TL, TR) :
    print('create your individual waveform plots here')

# make empty data and time Lists
LA_list = []
RV_list = []
RA_list = []
TL_list = []
TR_list = []

read_waveforms(LA_list, RV_list, RA_list)
read_times(TL_list, TR_list)

# convert all data and time lists to numpy arrays for plotting
LA = np.array(LA_list)
RV = np.array(RV_list)
RA = np.array(RA_list)
TL = np.array(TL_list[0])
TR = np.array(TR_list[0])

print("LA Mean:", np.mean( LA[2,:] ))
print("RV Mean:", np.mean( RV[2,:] ))
print("RA Mean:", np.mean( RA[2,:] ))

print("LA Min:", np.min( LA[2,:] ))
print("RV Min:", np.min( RV[2,:] ))
print("RA Min:", np.min( RA[2,:] ))

print("LA Max:", np.max( LA[2,:] ))
print("RV Max:", np.max( RV[2,:] ))
print("RA Max:", np.max( RA[2,:] ))

num_instances = len(LA)

for i in range(0, num_instances):
  
  plt.subplot( 311 )
  #plt.tight_layout()
  #<plot commands for linear acceleration waveform>
  plt.plot(TL, LA[i, :])
  plt.title('Lin Accel, Rot Vel and Rot Accel of Instance ' + str(i+1))
  plt.ylabel('Lin Acc(g)')
  plt.xticks(np.arange(0, 55, step=5))  
  
  plt.subplot( 312 )
  #plt.subplots_adjust(hspace=0.2)
  #<plot commands for rotational velocity waveform>
  plt.plot(TR, RV[i, :])
  #plt.title('Rotational Velocity of Instance ' + str(i+1))
  plt.ylabel('Rot Vel(rad/s)')
  plt.xticks(np.arange(0, 55, step=5))

  plt.subplot( 313 )
  #plt.subplots_adjust(hspace=0.2)
  #<plot command for rotational acceleration waveform>
  plt.plot(TR, RA[i, :])
  #plt.title('Rotational Acceleration of Instance ' + str(i+1))
  plt.xlabel('Time (ms)')
  plt.ylabel('Rot Acc(rad/s^2)')
  plt.xticks(np.arange(0, 55, step=5))

  plt.savefig('Instance ' + str(i + 1) + '.png')
  plt.show()